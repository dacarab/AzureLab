Configuration DomainController {
    param (
        [string]$LabName,
        [pscredential]$AdminCred
    )
    Import-DscResource -ModuleName xActiveDirectory
    Import-DscResource -ModuleName xNetworking
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -Modulename xDnsServer
    
    node LocalHost {    

        WindowsFeature DNS {
            Name = "DNS"
            Ensure = "Present"
        }

        WindowsFeature AD-Domain-Services {
            Name = "AD-Domain-Services"
            Ensure = "Present"
        }

        xADDomain LabName.Local {
            DomainAdministratorCredential = [PSCredential]$LabPassword
            DomainName = "$LabName.Local"
            SafemodeAdministratorPassword = $LabPassword
            DependsOn = "[WindowsFeature]AD-Domain-Services","[WindowsFeature]DNS"
        }

        Registry DisableNLA {
            Ensure = "Present"
            Key = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp"
            ValueName = "SecurityData"
            ValueData = "0"
        }
    }
}

